# V2.8

## Included in this package
- Default GitHub repository changed to `LessonSong`; repository setup guide updated.
- Transcript comparison choices are deduplicated by transcript ID to prevent duplicate DropdownButton values.
- File upload screen shows completed, pending, and failed counts while GitHub uploads are running.
- Added JSON settings export/import for GitHub connection and transcription settings. Empty imported fields are ignored.
- Added a double-confirmed local-data and media-cache reset when GitHub is not actively connected.
- DJ page uses a fixed-height queue section; the lesson/song lists and queue scroll independently.
- ZIP import table uses more compact row heights and column spacing while retaining horizontal scrolling.
- App version updated to 2.8.0.

## Not included yet
- FFmpeg-based audio trimming and noise reduction.
- ID3v2.3 MP3 tag editor and artwork embedding.
- Automatic media-cache/data refresh behavior beyond the existing GitHub synchronization.

## Validation
Flutter SDK is not available in the packaging environment; Flutter analyze/build was not run. Source-level checks and ZIP contents were inspected.
